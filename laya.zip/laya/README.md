# Central de despacho: Prolog vs Laya

Proyecto 2 · Fundamentos de Inteligencia Artificial · Universidad Andrés Bello.

Una empresa de reparto de carga local tiene una **central de despacho**. Antes de que un pedido
salga, alguien tiene que decidir qué hacer con él. Modelamos esa decisión y la resolvemos con dos
agentes que reciben **el mismo estado**:

- **Prolog**: reglas explícitas e inferencia lógica. Entrega la acción **y la demostración**.
- **Laya**: modelo estadístico de decisiones tipadas (checkpoint multilingüe, **sin entrenar**).
  Entrega la acción **y una distribución de probabilidades**.

**Pregunta del proyecto:** ¿cómo cambia la decisión cuando el mismo escenario se resuelve con
reglas explícitas y con un modelo estadístico?

| Acción | Cuándo |
|---|---|
| `despachar` | el vehículo asignado sirve, la ruta está despejada y conviene salir ya |
| `reasignar` | el asignado no sirve, pero un vehículo alternativo sí |
| `esperar` | no es urgente y todavía no puede o no conviene salir |
| `inspeccionar` | falta un dato necesario o los datos se contradicen |
| `alertar` | es urgente y no puede salir: decide el supervisor |

## Integrantes

| Nombre | Usuario de GitHub | Bloque principal |
|---|---|---|
| _Martin Montoya_ | | Modelo del dominio y Prolog |
| _Sebastian Jara_ | | Laya y front |
| _Bastian Carrillo_ | | Casos, experimento e informe |

## Resultados

Los 20 casos de evaluación (4 por categoría), con las decisiones esperadas definidas antes de
ejecutar:

| Agente | Aciertos | Comentario |
|---|---|---|
| Prolog | **20 / 20** | cada respuesta viene con su derivación |
| Laya (multilingüe, sin entrenar) | **3 / 20** | elige `esperar` en 18 casos; confianza media 0,40 cuando acierta y 0,42 cuando falla |

Al azar se esperarían 4 de 20. Las preguntas de diagnóstico (`score`/`noul`) muestran que Laya,
sin entrenar, tampoco resuelve los pasos simples (responde "sí" a casi todo). Detalle:
[`experimento/resultados.md`](experimento/resultados.md). Cómo se diseñó la pregunta de Laya:
[`experimento/disenio_pregunta.md`](experimento/disenio_pregunta.md) y
[`docs/agente_laya.md`](docs/agente_laya.md). Análisis: [`docs/informe.md`](docs/informe.md).

## 1. Requisitos

| Requisito | Versión usada | Notas |
|---|---|---|
| Python | 3.12.10 (sirve 3.10 o superior) | <https://www.python.org/downloads/> |
| SWI-Prolog | 10.0.2 (sirve 9.x o superior) | <https://www.swi-prolog.org/download/stable>; marcar "Add swipl to the system PATH" |
| Conexión a internet | solo la primera vez | Laya descarga el checkpoint multilingüe (~650 MB) |
| Espacio en disco | ~3 GB | PyTorch + checkpoint |
| GPU | no se necesita | con GPU NVIDIA Laya responde más rápido (ver abajo) |

## 2. Instalación (computador limpio)

**Windows (PowerShell):**

```powershell
git clone <url-del-repositorio>
cd <carpeta-del-repositorio>
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
swipl --version
```

Si PowerShell no deja activar el entorno: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

**macOS / Linux:**

```bash
git clone <url-del-repositorio>
cd <carpeta-del-repositorio>
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
swipl --version
```

Si `swipl` no está en el PATH, se puede indicar su ruta con la variable de entorno `SWIPL`.

### Laya en GPU (opcional)

`requirements.txt` instala PyTorch para CPU: cada caso tarda unos 2 segundos. Con una GPU NVIDIA
se puede instalar PyTorch con CUDA dentro del entorno virtual (la RTX 50xx necesita CUDA 12.8 o
superior), y Laya la usa sola:

```powershell
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu130
```

Para forzar la CPU: `$env:LAYA_DEVICE = "cpu"` antes de iniciar.

## 3. Ejecución

Todo se ejecuta desde la carpeta raíz del repositorio, con el entorno virtual activado.

### Aplicación web (demostración)

```powershell
python app/servidor.py
```

Abre `http://127.0.0.1:8000`. El servidor carga Prolog (un proceso `swipl` que queda abierto) y
Laya (en segundo plano) **una sola vez**. La primera ejecución de Laya descarga el checkpoint si
no está. Desde la app se puede:

- elegir uno de los 20 casos o crear uno nuevo, y editar el estado (formulario o JSON);
- ejecutar ambos agentes y ver por separado: acción de Prolog, acciones demostrables, datos
  faltantes, contradicciones y **árbol de derivación**; acción de Laya, **probabilidad de cada
  acción**, confianza, margen y estabilidad; las **preguntas de diagnóstico** (`score`/`noul`)
  frente a Prolog; y la comparación con la decisión esperada;
- **ejecutar los 20 casos** con un botón y ver métricas por agente, por categoría y de
  diagnóstico (descargables en CSV);
- escribir **consultas Prolog** sobre el estado del caso (por ejemplo `vehiculo_apto(p05, V)`);
- ver el **texto exacto** que recibe Laya.

Si se modifica `prolog/reglas.pl` con la app abierta, el cambio se aplica en la siguiente
ejecución, sin reiniciar. Opciones: `--puerto 8080`, `--sin-navegador`.

### Experimento completo (sin la app)

```powershell
python -m experimento.ejecutar
```

Ejecuta los 20 casos en Prolog y Laya y escribe `experimento/resultados.md`, `.csv` y `.json`.

### Diseño de la pregunta de Laya (conjunto de desarrollo)

```powershell
python -m laya_agent.generador            # 200 estados sintéticos (ya está en el repositorio)
python -m experimento.disenio_pregunta    # compara diseños de pregunta, sin usar los 20 casos
```

### Prolog por separado

```powershell
swipl prolog/consultas.pl                                  # 12 consultas comentadas
swipl prolog/verificar_casos.pl                            # los 20 casos contra la esperada
swipl prolog/ejecutar.pl casos/casos.json C09 --texto      # explicación de un caso
swipl                                                      # consola interactiva:
?- [prolog/reglas, prolog/hechos].
?- explicar(p90).
?- por_que_no(vehiculo_apto(p05, v50)).
```

### Pruebas

```powershell
swipl -g run_tests -t halt tests/test_reglas.pl            # 13 pruebas + 20 casos (plunit)
python -m unittest discover -s tests -v                    # 22 pruebas de Python
```

## 4. Estructura del repositorio

```
app/
  servidor.py            mini servidor web (biblioteca estándar): carga Prolog y Laya una vez
  static/                front: index.html, styles.css, app.js (sin dependencias)
casos/
  casos.json             los 20 casos de evaluación con su decisión esperada y criterio
docs/
  modelo_dominio.md      dominio, entidades, restricciones, supuestos, predicados, derivación
  estado_canonico.md     el estado común y cómo lo lee cada agente
  agente_laya.md         fundamentos de Laya: preguntas, sesgo de posición, salida, correspondencia
  informe.md             metodología, resultados, conclusiones y mejoras
  guia_defensa.md        cómo demostrar y cómo hacer modificaciones en vivo
  uso_ia.md              declaración del uso de herramientas de IA
experimento/
  ejecutar.py            corre los 20 casos y escribe los resultados
  resultados.md|csv|json resultados de la última ejecución
  disenio_pregunta.py    compara diseños de la pregunta de Laya en el conjunto de desarrollo
  disenio_pregunta.md    resultado de esa comparación
  desarrollo.jsonl       200 estados sintéticos (solo para diseñar la pregunta, nunca para entrenar)
laya_agent/
  pregunta.py            la pregunta choice (mismas 5 acciones de Prolog), rotaciones y diagnóstico
  estado_texto.py        traduce el estado JSON al texto que lee Laya (sin conclusiones)
  agente_laya.py         usa el checkpoint multilingüe, promedia los 5 órdenes, lee el diagnóstico
  agente_prolog.py       puente a Prolog: proceso swipl persistente
  comparacion.py         compara cada agente con la esperada y el diagnóstico con Prolog
  generador.py           genera el conjunto de desarrollo (estados sintéticos)
prolog/
  reglas.pl              base de conocimiento: reglas, prioridades, justificación
  estado_json.pl         JSON -> hechos (null -> desconocido/2)
  hechos.pl              pedidos de ejemplo escritos a mano (para la consola)
  consultas.pl           12 consultas comentadas
  servidor.pl            proceso que usa la app (una petición JSON por línea)
  ejecutar.pl            ejecuta un estado desde la terminal
  verificar_casos.pl     compara Prolog con la decisión esperada en los 20 casos
registros/
  laya.jsonl             cada ejecución de Laya: texto enviado, pregunta, respuesta, probabilidades
tests/
  test_reglas.pl         pruebas de Prolog (plunit)
  test_agentes.py        pruebas de Python (unittest)
```

## 5. Versiones usadas

| Componente | Versión |
|---|---|
| Sistema operativo | Windows 11 Pro |
| Python | 3.12.10 |
| SWI-Prolog | 10.0.2 |
| laya | 0.5.0 |
| Checkpoint | `convaiinnovations/laya`, subcarpeta `multilingual` (encoder mmBERT-base) |
| torch | 2.15.0 (CPU, lo instala `requirements.txt`) · 2.14.1+cu130 (GPU, opcional) |

## 6. Limitaciones conocidas

- **Laya no demuestra nada.** Su salida es una probabilidad (resultado experimental), no una
  prueba; puede equivocarse con una respuesta estable y con más confianza que otras (C15).
- **Laya sin entrenar no resuelve este dominio.** Acierta cerca del azar: no hace la aritmética
  implícita (carga / capacidad, capacidad máxima por tipo) ni encadena condiciones, y en las
  preguntas de diagnóstico responde "sí" a casi todo. Es el resultado esperado de comparar reglas
  explícitas con un modelo general sin conocimiento del dominio; no se entrenó por decisión del
  grupo y del profesor (ver `docs/agente_laya.md` §8).
- **Sesgo de posición.** La respuesta de Laya cambia según el orden de las alternativas; se
  mitiga promediando 5 órdenes, pero solo 7 de 20 casos son estables en los 5.
- **Confianza no calibrada para este dominio.** La confianza media es casi igual cuando acierta
  (0,40) y cuando falla (0,42): no sirve para decidir cuándo confiar en Laya.
- **Mundo cerrado en Prolog.** `\+` es negación por falla; los datos vacíos se marcan con
  `desconocido/2` para no confundir "no sé" con "no". Un dato ausente que no se marque así sí
  se trataría como falso.
- **Recorte del dominio.** Cada pedido se decide por separado (no se optimiza la flota) y los
  límites (capacidades máximas, 80 %, zona centro) son supuestos del grupo, no normas oficiales.
- **CPU y GPU** pueden dar probabilidades levemente distintas en Laya (precisión numérica).

## 7. Fuentes técnicas

- SWI-Prolog, manual oficial: <https://www.swi-prolog.org/pldoc/doc_for?object=manual>
  (negación por falla: sección 4.8; JSON: <https://www.swi-prolog.org/pldoc/man?section=json>;
  plunit: <https://www.swi-prolog.org/pldoc/doc_for?object=section(%27packages/plunit.html%27)>).
- Laya, documentación oficial: <https://nandhakishorm.github.io/laya/> · PyPI:
  <https://pypi.org/project/laya/> · modelo: <https://huggingface.co/convaiinnovations/laya>.
- Sesgo de posición y `option_order` en Laya: sección "Option order" de la documentación
  (README de laya 0.5.0 en PyPI); negación en preguntas `choice`: sección "Honest limits".
- PyTorch con CUDA: <https://pytorch.org/get-started/locally/>.

## 8. Uso de IA
se ocupo ia para definir bien las reglas de prolog e consultas

Ver [`docs/uso_ia.md`](docs/uso_ia.md).
