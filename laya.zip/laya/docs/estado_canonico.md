# Estado canónico (contrato común)

El estado canónico es la **única entrada** de ambos agentes. Describe un pedido y los vehículos
que podrían llevarlo, en el momento en que la central debe decidir.

- No incluye la conclusión: no hay campos como `"accion"`, `"apto"` ni `"urgente"`; tampoco
  porcentajes calculados ni nada que ya resuelva la decisión (lo verifica `tests/test_agentes.py`).
- Prolog lo lee con `prolog/estado_json.pl`, que lo convierte en hechos.
- Laya recibe el mismo JSON convertido a texto por `laya_agent/estado_texto.py` (ver abajo).
- Solo se envía el objeto `estado` de cada caso. **Nunca** se envían `decision_esperada` ni
  `criterio_esperada`.

## Ejemplo: caso C05

```json
{
  "pedido": "P05",
  "carga_kg": 1200,
  "tipo_carga": "general",
  "destino": "zona_norte",
  "urgencia": "media",
  "ruta_despejada": true,
  "vehiculo_asignado": {
    "id": "V50",
    "tipo_vehiculo": "camioneta",
    "capacidad_kg": 1000,
    "disponible": true,
    "en_mantencion": false,
    "combustible": "suficiente",
    "conductor_disponible": true
  },
  "vehiculos_alternativos": [
    {
      "id": "V51",
      "tipo_vehiculo": "furgon",
      "capacidad_kg": 3500,
      "disponible": true,
      "en_mantencion": false,
      "combustible": "suficiente",
      "conductor_disponible": true
    }
  ]
}
```

## Campos del pedido

| Campo | Tipo y valores permitidos | Significado | Hecho en Prolog |
|---|---|---|---|
| `pedido` | texto, p. ej. `"P05"` (obligatorio) | identificador del pedido | `pedido(p05).` |
| `carga_kg` | número | peso de la carga en kilos | `carga_kg(p05, 1200).` |
| `tipo_carga` | `general`, `refrigerada` | si la carga necesita frío | `tipo_carga(p05, general).` |
| `destino` | `centro`, `zona_norte`, `zona_sur`, `zona_oriente`, `zona_poniente` | zona de entrega | `destino(p05, zona_norte).` |
| `urgencia` | `alta`, `media`, `baja` | prioridad comercial del pedido | `urgencia(p05, media).` |
| `ruta_despejada` | `true`, `false` | si la ruta hacia el destino está transitable | `ruta_despejada(p05, si).` |
| `vehiculo_asignado` | objeto vehículo | el vehículo que propuso la planificación | `asignado(p05, v50).` + hechos del vehículo |
| `vehiculos_alternativos` | lista de objetos vehículo (puede ser `[]`) | otros vehículos libres que podrían llevar el pedido | `alternativo(p05, v51).` + hechos de cada uno |

## Campos de cada vehículo

| Campo | Tipo y valores permitidos | Significado | Hecho en Prolog |
|---|---|---|---|
| `id` | texto, p. ej. `"V50"` (obligatorio) | identificador del vehículo | `vehiculo(v50).` |
| `tipo_vehiculo` | `camioneta`, `furgon`, `furgon_refrigerado`, `camion` | tipo de vehículo | `tipo_vehiculo(v50, camioneta).` |
| `capacidad_kg` | número | carga máxima declarada en kilos | `capacidad_kg(v50, 1000).` |
| `disponible` | `true`, `false` | según el sistema de flota, no está ocupado en otro reparto | `disponible(v50, si).` |
| `en_mantencion` | `true`, `false` | según el registro del taller, está en mantención | `en_mantencion(v50, no).` |
| `combustible` | `suficiente`, `bajo` | si tiene combustible para el viaje | `combustible(v50, suficiente).` |
| `conductor_disponible` | `true`, `false` | si hay un conductor asignado y presente | `conductor_disponible(v50, si).` |

`disponible` y `en_mantencion` vienen de **dos sistemas distintos** (flota y taller). Por eso
pueden contradecirse, y esa contradicción es uno de los casos que el modelo detecta.

## Cómo se representa un dato que falta

| En el JSON | Significa | En Prolog |
|---|---|---|
| un campo con `null` (o ausente) | **no se sabe** | `desconocido(Entidad, campo).` |
| `"vehiculo_asignado": null` | no se sabe qué vehículo tiene asignado | `desconocido(p05, vehiculo_asignado).` |
| `"vehiculos_alternativos": []` | se sabe que **no hay** alternativos | ningún hecho `alternativo/2` |
| `"vehiculos_alternativos": null` | no se sabe si hay alternativos | `desconocido(p05, vehiculos_alternativos).` |

La diferencia entre `[]` y `null` importa: Prolog usa la negación por falla (lo que no puede
demostrar lo trata como falso), así que "no se sabe" tiene que quedar escrito de forma
explícita para no confundirse con "no hay".

## Regla de traducción a Prolog

Es mecánica y no agrega conclusiones:

1. Los identificadores se pasan a minúscula: `"P05"` → `p05`, `"V50"` → `v50`.
2. Cada campo con valor produce el hecho `campo(Entidad, valor)`.
3. `true` y `false` se escriben `si` y `no`.
4. Cada `null` produce `desconocido(Entidad, campo)`.

```prolog
?- [prolog/reglas, prolog/estado_json].
?- cargar_estado('mi_estado.json', P), explicar(P).
?- cargar_caso('casos/casos.json', 'C05', P, Esperada).
```

## Regla de traducción a texto (Laya)

Laya es un modelo de lenguaje: lee texto. `laya_agent/estado_texto.py` escribe cada campo como
una frase corta, siempre en el mismo orden, sin calcular nada:

```
Pedido P05. Carga: 1200 kg. Tipo de carga: general. Destino: zona norte. Urgencia: media. Ruta despejada: sí.
Vehículo asignado V50. Tipo: camioneta. Capacidad: 1000 kg. Disponible: sí. En mantención: no. Combustible: suficiente. Conductor disponible: sí.
Vehículo alternativo V51. Tipo: furgón. Capacidad: 3500 kg. Disponible: sí. En mantención: no. Combustible: suficiente. Conductor disponible: sí.
```

| En el JSON | En el texto |
|---|---|
| `true` / `false` | `sí` / `no` |
| `null` | `sin dato` (la misma expresión que usa la descripción de `inspeccionar`) |
| `"vehiculos_alternativos": []` | `Vehículos alternativos: ninguno.` |
| `"vehiculos_alternativos": null` | `Vehículos alternativos: sin dato.` |

No dice si la carga cabe ni qué porcentaje ocupa: eso tiene que deducirlo cada agente. El
texto exacto de cualquier estado se ve en la app (pestaña **Texto que lee Laya**).

## Cambios respecto del ejemplo del documento de reparto

El ejemplo inicial tenía un solo vehículo en campos planos (`vehiculo`, `tipo_vehiculo`,
`capacidad_kg`, `disponible`, `combustible`). Se propone:

| Cambio | Motivo |
|---|---|
| El vehículo pasa a un objeto `vehiculo_asignado` | La acción `reasignar` necesita comparar el asignado con **otro** vehículo; ambos se describen con los mismos campos y Prolog usa la misma regla `vehiculo_apto/2` para los dos |
| Se agrega `vehiculos_alternativos` (lista) | Sin alternativos no se puede decidir entre `reasignar`, `esperar` y `alertar` |
| Se agrega `tipo_carga` | Da una regla de compatibilidad (carga refrigerada solo en furgón refrigerado) |
| Se agrega `en_mantencion` | Segunda fuente sobre el vehículo; permite casos de contradicción con `disponible` |
| Se agrega `conductor_disponible` | El documento de reparto nombra al conductor como entidad del dominio |
| `destino` toma valores de zona, incluido `centro` | Da una restricción real: los camiones no entran al centro |

## Formato de los casos

`casos/casos.json` es una lista de 20 objetos con `id`, `categoria`, `descripcion`, `estado`,
`decision_esperada` y `criterio_esperada`. Valores de `categoria`: `directa`, `un_paso`,
`encadenada`, `incompleta`, `contradiccion` (4 casos cada una).

Probar un estado desde la terminal, sin la app:

```bash
swipl prolog/ejecutar.pl casos/casos.json C05 --texto     # explicación legible
swipl prolog/ejecutar.pl mi_estado.json                   # una línea JSON
swipl prolog/verificar_casos.pl                           # los 20 casos contra la esperada
```
