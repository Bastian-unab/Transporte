# Guía para la presentación y la defensa

Cada integrante es evaluado en **todo** el proyecto (dominio, Prolog, Laya, comparación,
resultados y modificación en vivo). Esta guía junta lo que hay que saber hacer sin ayuda.

## 1. Levantar la demo (30 segundos)

```powershell
.\.venv\Scripts\Activate.ps1
python app/servidor.py
```

Se abre `http://127.0.0.1:8000`. Arriba se ve si Prolog y Laya están listos.

| Para mostrar… | En la app |
|---|---|
| Un caso con ambos agentes | Elegir el caso a la izquierda → **Ejecutar ambos agentes** (Ctrl + Enter) |
| Un caso nuevo | **+ Caso nuevo**, editar el formulario, elegir la decisión esperada y ejecutar |
| Los 20 casos y las métricas | **Ejecutar los 20 casos** (pestaña Experimento) |
| Que Laya depende del orden de las alternativas | Tarjeta de Laya → "Respuesta según el orden de las alternativas" |
| Qué pasos intermedios acierta Laya | Tabla "Preguntas de diagnóstico" debajo de los resultados |
| Una consulta Prolog en vivo | Consola Prolog, debajo de los resultados |
| El texto exacto que lee Laya | Pestaña **Texto que lee Laya** del estado |

Enlaces directos útiles: `http://127.0.0.1:8000/#C09` abre C09; `/?ejecutar#C17` abre C17 y lo
ejecuta; `/?todos` corre los 20 casos.

## 2. Dónde está cada criterio de la rúbrica

| Criterio | Evidencia en el repositorio |
|---|---|
| G1 / I1 Dominio y estado común | `docs/modelo_dominio.md` §1–8, `docs/estado_canonico.md` |
| G2 / I2 Prolog e inferencia | `prolog/reglas.pl`, `prolog/consultas.pl` (12 consultas), derivación completa en `docs/modelo_dominio.md` §11 |
| G3 / I3 Laya | `laya_agent/pregunta.py`, `laya_agent/agente_laya.py`, `docs/agente_laya.md`, `experimento/disenio_pregunta.md`, `registros/laya.jsonl` |
| I4 Correspondencia | `docs/agente_laya.md` §10 |
| G4 / I5 Experimento | `casos/casos.json`, `experimento/resultados.md`, `docs/informe.md` |
| G5 Front | `app/servidor.py`, `app/static/` |
| G6 README | `README.md` |
| I7 Uso de IA | `docs/uso_ia.md` |
| I8 Commits | historial de git: cada integrante con commits propios en al menos 2 fechas y 2 componentes |

## 3. Preguntas probables

**¿Por qué el estado permite comparar a los dos agentes?** Los dos reciben el mismo JSON, que
solo tiene observaciones (kilos, tipo, si está en el taller…). Prolog lo convierte en hechos y
Laya en texto, ambos de forma mecánica. Ninguno recibe la decisión esperada ni campos ya
resueltos como "apto". Si difieren, la diferencia está en cómo razonan.

**¿Qué hace Prolog cuando le preguntas algo?** Busca una cláusula cuya cabeza **unifique** con
la meta, reemplaza la meta por el cuerpo de la cláusula y repite (resolución SLD) hasta llegar a
hechos. Si una submeta falla, **retrocede** a la última elección y prueba otra cláusula u otro
hecho. Ejemplo: en C09, `alternativa_apta(p09, W)` prueba `W = v91`.

**¿`\+` es la negación lógica?** No. Es negación por falla: "no se pudo demostrar con los hechos
que hay". Por eso un dato que falta se registra con `desconocido/2`; si no, Prolog confundiría
"no sé si es urgente" con "no es urgente" (C13).

**¿Qué pasa con una consulta sin solución, con varias o con una contradicción?**
`accion_candidata(p01, reasignar)` → `false`. `acciones_candidatas(p19, L)` →
`[inspeccionar, reasignar]`: hay dos acciones demostrables y la prioridad elige. En C18
`contradiccion(p18, T)` → `T = disponible_y_en_mantencion(v18)`.

**¿Qué es `choice`, `score` y `noul`?** `choice` elige una alternativa entre varias con nombre:
es la decisión (5 acciones). `score` da un nivel en una escala ordenada: la usamos para la
urgencia (baja/media/alta). `noul` responde sí/no y devuelve la probabilidad del "sí": la usamos
para "¿falta un dato?", "¿hay contradicción?" y "¿el asignado sirve?". Las `score` y `noul` son
de diagnóstico: no deciden, se comparan con `urgencia/2`, `falta_dato_critico/2`,
`contradiccion/2` y `vehiculo_apto/2`.

**¿La confianza de Laya demuestra algo?** No. Es la probabilidad que el modelo le asigna a la
acción elegida: un resultado experimental. Prolog sí demuestra: su respuesta viene con la
derivación de hechos y reglas. Laya puede equivocarse con confianza alta.

**¿Por qué no entrenaron Laya?** El enunciado no lo exige y la rúbrica no lo pide. Si se
entrena con etiquetas que salen de Prolog, Laya aprende a imitar a Prolog y la comparación se
vuelve circular. Lo que sí se diseñó es **cómo se le pregunta** (texto, descripciones, rotación
de alternativas), eligiendo con 200 estados de desarrollo y nunca con los 20 casos.

**¿Por qué rotan las alternativas?** La documentación de Laya muestra un sesgo de posición: el
lugar de una alternativa cambia su puntaje aunque el texto sea igual. Se hace la misma pregunta
con 5 órdenes (en una sola llamada) y se promedia. La "estabilidad" dice cuántos órdenes eligen
lo mismo: en los 20 casos, solo 7 son 5/5.

**¿Le dieron más contexto a Laya?** Sí. Se le pasaron como texto las mismas reglas generales que
Prolog tiene en `reglas.pl`, y en otra prueba frases calculadas por caso ("la carga no cabe").
Ninguna mejora: con las reglas eligió `esperar` en los 200 estados de desarrollo, con confianza
0,86. Laya no ejecuta lo que lee; el texto extra compite con los datos del caso
(`experimento/disenio_pregunta.md`, diseños 4 y 5).

**¿Por qué Laya acierta tan poco?** No tiene reglas: lee el texto y compara con la descripción
de cada acción. No hace la cuenta 1200 > 1000 (C05) ni sabe la capacidad máxima de una camioneta
(C20). El diagnóstico muestra que ni siquiera lee bien los datos directos: responde "sí" a casi
todas las `noul`. En C15 reacciona a la palabra "sin dato" y elige inspeccionar, mientras Prolog
sabe que ese dato no importa.

## 4. Modificaciones en vivo (I6)

Las cinco acciones que pide la rúbrica: **identificar archivos → cambiar Prolog → adaptar Laya →
ejecutar ambos → explicar el cambio**. Con la app abierta, Prolog recarga `reglas.pl` solo; si hay
un error de sintaxis, la app lo muestra en la tarjeta de Prolog.

Cada cláusula nueva va **junto a las otras cláusulas del mismo predicado** (por ejemplo,
`accion(tercerizar).` debajo de `accion(alertar).`). Si se agrega al final del archivo, funciona
igual, pero SWI-Prolog avisa "Clauses of … are not together" y la app muestra ese aviso.

Después de cada cambio en Prolog:

```powershell
swipl prolog/verificar_casos.pl          # qué casos cambian de decisión
swipl -g run_tests -t halt tests/test_reglas.pl
```

### A. Cambiar un umbral: aprovechamiento mínimo de 80 % a 95 %

1. Archivo: `prolog/reglas.pl`, hecho `umbral(aprovechamiento_alto, 0.8).` → `0.95`.
2. Ejecutar C07 en la app: Prolog pasa de `despachar` a `esperar` (1350/1500 = 90 % < 95 %).
3. Laya: la descripción de `despachar`/`esperar` habla de "casi vacío" sin número; se puede
   reescribir en `CRITERIOS` (`laya_agent/pregunta.py`), por ejemplo "el vehículo iría con menos
   del 95 % de su capacidad", y reiniciar la app.
4. Ejecutar C07 otra vez: Prolog cambia con certeza; Laya puede o no cambiar.
5. Explicación: **Prolog cambia de inmediato porque la regla es explícita y la aplica exacta;
   en Laya el número es solo una palabra más del texto: no hace la división 1350 / 1500.**

### B. Nuevo tipo de carga `fragil`, que solo puede ir en furgón

1. `prolog/reglas.pl`, agregar junto a `tipo_compatible/2`:
   ```prolog
   tipo_compatible(P, V) :- tipo_carga(P, fragil), tipo_vehiculo(V, furgon).
   ```
2. En la app, abrir C04, pestaña JSON, cambiar `"tipo_carga": "general"` por `"fragil"` y
   ejecutar: con la regla da `reasignar` (el alternativo es furgón); sin la regla, `esperar`
   (ningún vehículo es compatible).
3. Laya: el texto ya dice "Tipo de carga: fragil" (pestaña "Texto que lee Laya"). Se puede
   agregar a la descripción de `reasignar` en `CRITERIOS`: "…o la carga es frágil y el asignado no
   es furgón". Reiniciar la app y ejecutar: la respuesta de Laya es experimental.

### C. Nueva contradicción: capacidad cero o negativa

1. `prolog/reglas.pl`, sección 5:
   ```prolog
   contradiccion(P, capacidad_no_positiva(V)) :-
       vehiculo_relevante(P, V), capacidad_kg(V, K), K =< 0.
   ```
2. App: C01, cambiar la capacidad del asignado a `0` y ejecutar. Sin la regla da `alertar`
   (800 kg no caben en 0 kg y el pedido es urgente: Prolog no ve nada raro). Con la regla da
   `inspeccionar`, con la contradicción listada.
3. Laya: el criterio de `inspeccionar` ya habla de "una capacidad imposible".

### D. Nueva acción `tercerizar` (contratar transporte externo)

1. `prolog/reglas.pl`:
   ```prolog
   accion(tercerizar).
   prioridad(tercerizar, 1.5).     % entre inspeccionar (1) y alertar (2)
   accion_candidata(P, tercerizar) :-
       urgente(P), sin_vehiculo_apto(P), ruta_despejada(P, si).
   ```
2. `laya_agent/pregunta.py`: agregar `"tercerizar"` al final de `ACCIONES` y su descripción en
   `CRITERIOS` (mismo orden; hay un `assert` que lo revisa), por ejemplo: *"el pedido es urgente,
   ningún vehículo propio sirve y la ruta está despejada: se contrata transporte externo"*.
3. Reiniciar la app (Ctrl+C y `python app/servidor.py`): el front toma la lista nueva solo.
4. C06 y C10 pasan de `alertar` a `tercerizar` en Prolog; C02 sigue en `alertar` (ruta cortada).
5. Laya ya puede elegir `tercerizar` (la pregunta tiene 6 alternativas y la rotación usa 6
   órdenes automáticamente).
6. `python -m unittest tests.test_agentes` confirma que Prolog y Laya tienen las mismas acciones.

### E. Un caso nuevo pedido por el evaluador

1. App → **+ Caso nuevo**. Completar el formulario según lo que dicten.
2. Elegir la **decisión esperada** antes de ejecutar (como en el experimento).
3. Ejecutar; mostrar la derivación de Prolog y las probabilidades de Laya.
4. Si conviene, probar en la consola: `por_que_no(vehiculo_apto(p99, v990))`.

## 5. Seguir una derivación sin ayuda (C09)

```
?- [prolog/reglas, prolog/estado_json].
?- cargar_caso('casos/casos.json', 'C09', P, E), explicar(P).
?- trace, decidir(p09, A, _).
```

Leer el árbol de la app de arriba hacia abajo: `accion_candidata(p09,reasignar)` se obtuvo con
una regla; su primera condición `asignado(p09,v90)` es un hecho; `\+ vehiculo_apto(p09,v90)` se
cumple porque `tipo_compatible(p09,v90)` falla (carga refrigerada en camión); luego
`alternativa_apta(p09,v91)` se demuestra con las cuatro condiciones de `vehiculo_apto`.
