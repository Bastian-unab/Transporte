# Informe: Prolog vs Laya en una central de despacho de carga

> Borrador generado con los resultados del 19-11-2026. El grupo debe revisarlo, completarlo con
> su análisis propio y actualizar las cifras si vuelve a ejecutar el experimento.

## 1. Problema

Una empresa de reparto de carga local decide, pedido por pedido, qué hacer antes de que salga:
**despachar**, **reasignar** a otro vehículo, **esperar**, **inspeccionar** los datos o
**alertar** al supervisor. La decisión depende de observaciones concretas: peso de la carga,
capacidad y tipo del vehículo, si está libre o en el taller, combustible, conductor, zona de
destino y estado de la ruta. El detalle del dominio está en [`modelo_dominio.md`](modelo_dominio.md).

**Pregunta del proyecto:** ¿cómo cambia la decisión cuando el mismo escenario se resuelve con
reglas explícitas en Prolog y con un modelo estadístico de decisiones en Laya?

## 2. Decisiones de modelado

| Decisión | Motivo |
|---|---|
| Un estado común con **solo observaciones** (sin campos como "apto" o "urgente") | Que ningún agente reciba la conclusión hecha; si difieren, la diferencia está en cómo razonan |
| Vehículo asignado + lista de alternativos, con los mismos campos | La misma regla `vehiculo_apto/2` sirve para ambos; habilita `reasignar` |
| Dos fuentes para el vehículo (`disponible` de la flota, `en_mantencion` del taller) | Permite contradicciones reales |
| `null` → `desconocido/2` en Prolog y "sin dato" en Laya | Prolog usa negación por falla: sin esto, "no sé" se leería como "no" |
| Prioridad entre acciones (inspeccionar > alertar > reasignar > despachar > esperar) | Resolver cuando hay varias acciones demostrables (C17, C19) |
| Laya recibe el estado como texto, traducido campo por campo | Laya es un modelo de lenguaje; la traducción no agrega conclusiones |
| Laya **sin entrenar** | No lo exige el enunciado; entrenar con etiquetas de Prolog volvería circular la comparación |

## 3. Metodología

1. **Casos.** 20 casos, 4 por categoría (información directa, inferencia de un paso, inferencia
   encadenada, información incompleta, contradicción o ambigüedad). Cada caso tiene una decisión
   esperada y un criterio escritos **antes** de ejecutar los agentes (`casos/casos.json`).
2. **Mismo estado.** Ambos agentes reciben el mismo JSON; ninguno recibe la decisión esperada.
3. **Diseño de la pregunta de Laya sin mirar los 20 casos.** Se generaron 200 estados sintéticos
   de desarrollo (40 por acción) y en ellos se compararon formatos y órdenes de alternativas
   (`experimento/disenio_pregunta.md`). Los 20 casos se ejecutaron una vez, con el diseño elegido.
4. **Métricas.**
   - aciertos globales y por categoría;
   - acuerdo entre agentes y matriz de confusión de Laya;
   - confianza media de Laya cuando acierta y cuando falla;
   - estabilidad frente al orden de las alternativas;
   - aciertos en las preguntas de diagnóstico (`score`/`noul`) frente al predicado de Prolog
     equivalente.

## 4. Resultados

### Decisión

| | Prolog | Laya |
|---|---|---|
| Aciertos | **20 / 20** | **3 / 20** (al azar: 4 / 20) |
| Acuerdo entre agentes | — | 3 / 20 |
| Acciones elegidas | las 5 | `esperar` 18, `inspeccionar` 2 |
| Confianza media de Laya (acierta / falla) | — | 0,40 / 0,42 |
| Casos con los 5 órdenes de acuerdo | — | 7 / 20 |

| Categoría | Prolog | Laya |
|---|---|---|
| Información directa | 4/4 | 1/4 |
| Inferencia de un paso | 4/4 | 1/4 |
| Inferencia encadenada | 4/4 | 1/4 |
| Información incompleta | 4/4 | 0/4 |
| Contradicción o ambigüedad | 4/4 | 0/4 |

### Preguntas de diagnóstico de Laya

| Pregunta | Tipo | Coincide con Prolog (20 casos) | En desarrollo (200) |
|---|---|---|---|
| Urgencia del pedido | score | 7/19 | 32 % (azar: 33 %) |
| ¿Falta un dato necesario? | noul | 2/20 | 36 % (dice "sí" el 74 %) |
| ¿Hay datos contradictorios? | noul | 3/20 | 8 % (dice "sí" el 99 %) |
| ¿El asignado puede llevar el pedido? | noul | 8/20 | 35 % (dice "sí" el 100 %) |

### Diseño de la pregunta (conjunto de desarrollo, 200 estados)

| Diseño | Aciertos |
|---|---|
| JSON crudo, un orden | 19 % |
| Texto, un orden | 22 % |
| Texto + reglas de la central como contexto, 5 órdenes | 20 % (siempre `esperar`, confianza 0,86) |
| Texto + observaciones calculadas por caso, 5 órdenes | 18 % |
| Texto, 5 órdenes promediados (final) | 26 % |

## 5. Análisis

**Prolog acierta los 20 casos**, y en cada uno muestra la derivación. Esto no es un mérito "del
modelo" por sí solo: las reglas son la política de la central escrita de forma explícita, y los
casos se diseñaron con esa política. Lo valioso es *cómo* llega:

- **C15:** sabe que la lista de alternativos desconocida no importa porque el asignado sirve
  (`falta_dato_critico/2` solo la exige si el asignado no sirve).
- **C17 y C19:** hay dos acciones demostrables a la vez, y la prioridad resuelve de forma
  explícita y explicable.
- **C20:** detecta la capacidad imposible comparando con `capacidad_maxima/2`.

**Laya acierta 3 de 20, menos que el azar (4 de 20).** Sus tres aciertos (C03, C08, C11) son
casos cuya respuesta correcta es `esperar`, la acción que elige casi siempre. En C11 la
estabilidad es 2/5: con otro orden de alternativas habría respondido otra cosa. **Acertar no
significa haber razonado.**

**Dónde falla y por qué:**
- **Aritmética implícita.** En C05 (1200 kg en 1000 kg) y C07 (90 % de ocupación) la decisión
  depende de una cuenta. Laya no la hace: en C05 su pregunta de diagnóstico dice que el asignado
  sirve con P(sí) = 0,99.
- **Información incompleta.** En C15 elige `inspeccionar` con estabilidad 5/5 y la confianza más
  alta de los 20 casos (0,56): reacciona a las palabras "sin dato" sin saber si el dato importa.
  En C13, donde sí falta un dato crítico, responde `esperar`.
- **Contradicciones.** Ninguna detectada: la pregunta `noul` de contradicción dice "sí" en casi
  todos los estados, haya o no contradicción.
- **Confianza no informativa.** La confianza media es casi la misma cuando acierta (0,40) y
  cuando falla (0,42), y siempre está lejos de 1. Laya "no sabe" en todos los casos, y su
  confianza no ayuda a distinguir cuándo creerle.
- **Sesgo de posición.** Solo 7 de 20 casos dan la misma acción en los 5 órdenes de
  alternativas, y en desarrollo solo 12 de 200. Promediar los 5 órdenes lo mitiga (de 22 % a
  26 % en desarrollo) y además baja la confianza aparente, que con un solo orden era engañosa.

**Más contexto no ayuda.** Darle a Laya, como texto, las mismas reglas generales que tiene
Prolog la llevó a elegir `esperar` en todos los estados de desarrollo, con una confianza de 0,86,
más del doble que sin contexto. Prolog *aplica* las reglas; Laya solo las *lee* como parte del
texto que clasifica, y más texto sube su confianza sin subir su acierto.

**Las preguntas de diagnóstico muestran que el problema empieza antes del razonamiento.** Laya,
sin entrenar, tampoco resuelve los pasos de un solo dato: la urgencia la acierta como al azar y a
las `noul` responde "sí" casi siempre. No es solo que no encadene reglas; con este estado y sin
conocimiento del dominio, no extrae los datos de forma confiable.

## 6. Conclusiones

1. **Ante el mismo estado, Prolog y Laya hacen cosas distintas.** Prolog *demuestra* una acción
   a partir de hechos y reglas explícitas, y puede explicar cada paso. Laya *estima*
   probabilidades sobre alternativas descritas en texto. Sin conocimiento del dominio, esa
   estimación queda cerca del azar.
2. **El tipo de caso marca la diferencia.** Las categorías que exigen aritmética, encadenar
   condiciones o saber si un dato faltante importa son justamente las que Laya no resuelve.
   Prolog las resuelve porque esas relaciones están escritas.
3. **La salida de Laya es experimental.** Una respuesta estable o con más confianza puede estar
   mal (C15), y un acierto puede ser casualidad (C11). Las probabilidades no reemplazan una
   demostración.
4. **La redacción y el orden de la pregunta influyen en Laya, y en Prolog no.** Cambiar el
   formato o el orden de las alternativas cambia sus respuestas; en Prolog, solo cambiar una
   regla cambia la decisión, y cambia de forma predecible.

## 7. Limitaciones

- 20 casos son pocos para medir diferencias finas; por eso el diseño de Laya se midió en 200
  estados de desarrollo.
- Los estados de desarrollo se etiquetaron con la misma política que Prolog: sirven para elegir
  la pregunta, no para medir a Prolog.
- Los límites del dominio (capacidades máximas, 80 %, zona centro) son supuestos del grupo.
- Solo se probó el checkpoint multilingüe pedido por el enunciado (y, como referencia en
  desarrollo, el motor por defecto de laya 0.5, con resultados similares).

## 8. Propuestas de mejora

1. **Combinar los enfoques (neuro-simbólico).**
   - Laya para lo que hace bien: leer texto libre (mensajes de conductores o clientes, como "el
     camión quedó en el taller") y llenar campos del estado.
   - Prolog para decidir sobre ese estado.
2. **Si se permitiera entrenar**, hacerlo con decisiones reales de despachadores y no con
   etiquetas de Prolog, para que la comparación siga siendo justa.
3. **Usar la revisión humana de Laya 0.5** (`abstain`, `prediction_set`, `route`) para derivar
   automáticamente a una persona los casos en que el modelo no distingue.
4. **Ampliar Prolog:**
   - decidir varios pedidos a la vez (asignar la flota completa);
   - ventanas horarias;
   - horas de conducción.
