# Uso de herramientas de inteligencia artificial

El enunciado (sección 11) permite usar asistentes de IA, pero pide declarar las herramientas y
conservar evidencia de las decisiones humanas que llevaron a aceptar, modificar o rechazar cada
sugerencia. Este archivo es esa evidencia.

> **Para completar por el grupo:** la columna "Decisión del grupo" y el nombre de quien la
> revisó. Una sugerencia sin decisión registrada no debería quedar en la entrega.

## Herramientas utilizadas

| Herramienta | Para qué | Fecha |
|---|---|---|
| Claude (Anthropic), en Claude Code | Analizar el enunciado y la rúbrica; reorganizar el repositorio; diseñar las preguntas de Laya y medirlas en un conjunto de desarrollo; escribir el servidor, el front, las pruebas y la documentación | 19-11-2026 |

El uso de un LLM **no** forma parte de la comparación principal: los agentes comparados son
Prolog y Laya. Ningún LLM decide casos dentro de la aplicación.

## Qué se reutilizó del trabajo previo del grupo

- Base de conocimiento de Prolog (`prolog/reglas.pl`, `hechos.pl`, `estado_json.pl`,
  `consultas.pl`): reglas, prioridades, meta-intérprete de justificación y consultas.
- Estado canónico y modelo del dominio (`docs/estado_canonico.md`, `docs/modelo_dominio.md`).
- Casos C01–C16, C18 y C20 con sus decisiones esperadas y criterios.
- Primera ejecución de Laya (3 de 20 aciertos), usada como línea base.

## Sugerencias de la IA y decisión del grupo

| # | Sugerencia | Motivo dado | Decisión del grupo (aceptar / modificar / rechazar) | Revisó |
|---|---|---|---|---|
| 1 | Reemplazar C17 (combustible bajo) y C19 (falta urgencia) por un caso de ambigüedad y uno de contradicción | C17 era inferencia encadenada y C19 repetía C13; la categoría 5 quedaba con 2 casos reales | | |
| 2 | Enviar a Laya el estado como texto en español generado campo por campo, en vez del JSON crudo | Laya lee texto; los `false` del JSON son negaciones que la documentación de Laya advierte que maneja mal | | |
| 3 | Entrenar (fine-tuning) el checkpoint multilingüe con estados sintéticos etiquetados por Prolog | Sin entrenar, Laya elegía casi siempre la misma acción (3/20) | **Rechazada.** El profesor indicó que no corresponde entrenar a Laya; además, entrenarla con etiquetas de Prolog vuelve circular la comparación. Se borró el código y el modelo | |
| 4 | Diseñar la pregunta de Laya con un conjunto de desarrollo de 200 estados sintéticos, sin mirar los 20 casos | Elegir la redacción con evidencia y sin ajustar la pregunta a los casos de evaluación | | |
| 4b | Rotar el orden de las alternativas (5 órdenes) y promediar | La documentación de Laya muestra sesgo de posición; en desarrollo sube de 22 % a 26 % y deja medir la estabilidad | | |
| 4c | Preguntas de diagnóstico `score`/`noul` comparadas con predicados de Prolog | Ver en qué paso falla Laya y usar los tres tipos de pregunta | | |
| 4d | Dar a Laya más contexto (reglas generales como texto; observaciones por caso) | El profesor indicó que se le puede dar más contexto | Probado en desarrollo: no mejora (20 % y 18 %). Se deja documentado en `laya_agent/contexto.py` y no se usa en el agente final | |
| 4e | Usar el checkpoint oficial `typed-decisions` con el texto en inglés | En desarrollo sube a 45 % sin entrenar | Pendiente: consultar al profesor (el enunciado pide el multilingüe para texto en español) | |
| 5 | Dejar una sola versión de la pregunta de Laya (sin "v1/v2") | Simplificar la comparación y la defensa | | |
| 6 | Proceso Prolog persistente que recarga `reglas.pl` si cambió | Modificaciones en vivo (I6) sin reiniciar la app | | |
| 7 | Servidor con la biblioteca estándar de Python y front sin dependencias | Menos pasos de instalación en un computador limpio | | |

## Qué validó el grupo (completar)

- [ ] Las 20 decisiones esperadas y sus criterios corresponden a la política de la central.
- [ ] Cada integrante ejecutó la app y los 20 casos en su computador.
- [ ] Cada integrante puede explicar `reglas.pl`, la pregunta de Laya (rotación y diagnóstico) y el conjunto de desarrollo sin ayuda.
- [ ] Se revisaron los resultados de `experimento/resultados.md` y las observaciones.
