# Analogía con Breakthrough (Proyecto 1)

Responsable: Persona 1 (tarea secundaria). Insumo para el informe final que integra Persona 3.

El enunciado permite usar los juegos de proyectos anteriores **como ejemplo de modelado**, pero
no como dominio final. Este documento explica qué del modelado de Breakthrough se reutilizó en
el despacho de carga y qué tuvo que cambiar.

> **Completar antes de entregar:** las partes marcadas con ✎ dependen de cómo implementamos el
> Proyecto 1 (algoritmo y función de evaluación). No inventar: revisar el código del Proyecto 1.

## 1. Los dos problemas lado a lado

| Elemento | Breakthrough (Proyecto 1) | Despacho de carga (Proyecto 2) |
|---|---|---|
| Estado | tablero 8 × 8 con las piezas de cada jugador | un pedido, su vehículo asignado y los alternativos (`docs/estado_canonico.md`) |
| ¿Se observa todo? | sí: información perfecta | no siempre: hay datos vacíos (`null`) y fuentes que se contradicen |
| Acciones | mover una pieza un casillero hacia adelante (recto o en diagonal) | cinco acciones fijas: despachar, reasignar, esperar, inspeccionar, alertar |
| Restricciones | de frente solo a casilla vacía; captura solo en diagonal; no se pisa una pieza propia | capacidad, tipo de carga, zona restringida, vehículo operativo, ruta |
| Objetivo | llegar a la última fila del rival o capturar todas sus piezas | elegir la acción correcta para el pedido según la política del grupo |
| Adversario | sí: el otro jugador responde | no: la decisión es de un solo paso |
| Cómo decidía el agente | ✎ (p. ej., búsqueda en el árbol de jugadas con una función de evaluación) | Prolog: inferencia lógica sobre reglas; Laya: elección estadística entre alternativas descritas |

## 2. Qué se reutilizó

**Separar estado, acciones admisibles y política.** En Breakthrough primero hay que saber qué
movimientos son legales y recién después elegir el mejor. En el despacho ocurre lo mismo:
`vehiculo_apto/2` y las restricciones filtran lo que es posible, y `accion_candidata/2` con
`prioridad/2` elige entre lo posible.

Las reglas de Breakthrough se escriben en Prolog igual que las restricciones del despacho:

```prolog
% pieza(Color, Fila, Columna). Las blancas avanzan hacia filas mayores.
avance(blanca, 1).
avance(negra, -1).

dentro(F, C) :- F >= 1, F =< 8, C >= 1, C =< 8.

% movimiento_legal(Color, Desde, Hasta)
movimiento_legal(Color, c(F, C), c(F2, C2)) :-
    pieza(Color, F, C),
    avance(Color, D),
    F2 is F + D,
    member(DC, [-1, 0, 1]),
    C2 is C + DC,
    dentro(F2, C2),
    \+ pieza(Color, F2, C2),            % no se puede pisar una pieza propia
    (   DC =:= 0
    ->  \+ pieza(_, F2, C2)             % de frente: solo a una casilla vacía
    ;   true                            % en diagonal: casilla vacía o captura
    ).
```

Con blancas en (2,4) y (2,5) y negras en (3,4) y (3,5), `findall(D-H, movimiento_legal(blanca, D, H), L)`
devuelve los cuatro movimientos diagonales y ninguno de frente, que es lo correcto.

La correspondencia:

| Breakthrough | Despacho |
|---|---|
| `movimiento_legal/3` filtra jugadas | `vehiculo_apto/2` filtra vehículos |
| `\+ pieza(Color, F2, C2)`: no pisar una pieza propia | `\+ zona_restringida(Zona, Tipo)`: no entrar a una zona prohibida |
| ✎ la función de evaluación ordena las jugadas legales | `prioridad/2` ordena las acciones demostrables |
| una jugada se describe por su origen y destino | una acción se describe por la regla que la demuestra (justificación) |

**El estado como lista de hechos sobre entidades.** En Breakthrough cada pieza es un hecho
`pieza(Color, Fila, Columna)`; aquí cada propiedad es un hecho `campo(Entidad, Valor)`. En ambos
casos las reglas se escriben con variables y sirven para cualquier pieza o vehículo.

## 3. Qué tuvo que cambiar

| Problema nuevo | Cómo se resolvió |
|---|---|
| **Información incompleta.** En Breakthrough el tablero siempre está completo. Aquí un dato puede faltar, y la negación por falla lo trataría como falso. | Cada `null` se registra como `desconocido/2` y `falta_dato_critico/2` decide cuándo ese dato importa. |
| **Fuentes contradictorias.** En el tablero no hay contradicciones; aquí la flota y el taller pueden informar cosas incompatibles. | `contradiccion/2` y la acción `inspeccionar` con la prioridad más alta. |
| **No hay adversario.** No tiene sentido buscar en un árbol de jugadas. | La decisión es una sola inferencia; la "búsqueda" es la resolución SLD de Prolog con retroceso (por ejemplo, entre vehículos alternativos). |
| **Las acciones no son jugadas generadas, sino un conjunto fijo.** | Las mismas cinco acciones para Prolog y Laya, lo que permite comparar ambos agentes caso a caso. |
| **Hay que justificar la decisión.** En un juego basta con jugar bien. | `decidir/3` devuelve la derivación completa (meta-intérprete). |

## 4. Relación con Laya

La demo de Laya Snake del curso muestra la misma idea aplicada a un juego: el programa calcula y
describe los movimientos posibles y Laya elige entre esas descripciones. En Breakthrough, Laya
podría elegir entre jugadas legales descritas en texto; en el despacho elige entre las cinco
acciones descritas en la pregunta `choice`. En ambos casos **Laya no garantiza que la elección
respete las reglas**: por eso en Snake existe un "escudo" externo y aquí comparamos su respuesta
con la de Prolog y con la decisión esperada.
